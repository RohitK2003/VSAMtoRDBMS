      ******************************************************************
      * Account Record Structure - From CVACT01Y.cpy
      ******************************************************************
           05  EXPORT-ACCOUNT-DATA REDEFINES EXPORT-RECORD-DATA.
               10  EXP-ACCT-ID                     PIC 9(11).
               10  EXP-ACCT-ACTIVE-STATUS          PIC X(01).
               10  EXP-ACCT-CURR-BAL               PIC S9(10)V99 COMP-3.
               10  EXP-ACCT-CREDIT-LIMIT           PIC S9(10)V99.
               10  EXP-ACCT-CASH-CREDIT-LIMIT      PIC S9(10)V99 COMP-3.
               10  EXP-ACCT-OPEN-DATE              PIC X(10).
               10  EXP-ACCT-EXPIRAION-DATE         PIC X(10).
               10  EXP-ACCT-REISSUE-DATE           PIC X(10).
               10  EXP-ACCT-CURR-CYC-CREDIT        PIC S9(10)V99.
               10  EXP-ACCT-CURR-CYC-DEBIT         PIC S9(10)V99 COMP.
               10  EXP-ACCT-ADDR-ZIP               PIC X(10).
               10  EXP-ACCT-GROUP-ID               PIC X(10).
               10  FILLER                          PIC X(352).
