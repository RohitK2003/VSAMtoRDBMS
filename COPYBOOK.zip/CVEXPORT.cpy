 ******************************************************************
      * CVEXPORT.cpy - CardDemo Multi-Record Export Layout
      * This copybook defines the structure for export records
      * stored in the sequential export file for branch migration
      * Total Record Length: 500 bytes
      * Storage Optimization: COMP/COMP-3 fields for numeric data
      * Enhancement: Multiple record types with REDEFINES structure
      ******************************************************************
       01  EXPORT-RECORD.
           05  EXPORT-REC-TYPE                         PIC X(1).
           05  EXPORT-TIMESTAMP                        PIC X(26).
           05  EXPORT-TIMESTAMP-R REDEFINES EXPORT-TIMESTAMP.
               10  EXPORT-DATE                         PIC X(10).
               10  EXPORT-DATE-TIME-SEP                PIC X(1).
               10  EXPORT-TIME                         PIC X(15).
           05  EXPORT-SEQUENCE-NUM                     PIC 9(9) COMP.
           05  EXPORT-BRANCH-ID                        PIC X(4).
           05  EXPORT-REGION-CODE                      PIC X(5).
           05  EXPORT-RECORD-DATA                      PIC X(460).
