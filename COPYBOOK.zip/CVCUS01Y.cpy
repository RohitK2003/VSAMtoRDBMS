      ******************************************************************
      * Customer Record Structure - From CVCUS01Y.cpy
      ******************************************************************
           05  EXPORT-CUSTOMER-DATA REDEFINES EXPORT-RECORD-DATA.
               10  EXP-CUST-ID                     PIC 9(09) COMP.
               10  EXP-CUST-FIRST-NAME             PIC X(25).
               10  EXP-CUST-MIDDLE-NAME            PIC X(25).
               10  EXP-CUST-LAST-NAME              PIC X(25).
               10  EXP-CUST-ADDR-LINES OCCURS 3 TIMES.
                   15  EXP-CUST-ADDR-LINE          PIC X(50).
               10  EXP-CUST-ADDR-STATE-CD          PIC X(02).
               10  EXP-CUST-ADDR-COUNTRY-CD        PIC X(03).
               10  EXP-CUST-ADDR-ZIP               PIC X(10).
               10  EXP-CUST-PHONE-NUMS OCCURS 2 TIMES.
                   15  EXP-CUST-PHONE-NUM          PIC X(15).
               10  EXP-CUST-SSN                    PIC 9(09).
               10  EXP-CUST-GOVT-ISSUED-ID         PIC X(20).
               10  EXP-CUST-DOB-YYYY-MM-DD         PIC X(10).
               10  EXP-CUST-EFT-ACCOUNT-ID         PIC X(10).
               10  EXP-CUST-PRI-CARD-HOLDER-IND    PIC X(01).
               10  EXP-CUST-FICO-CREDIT-SCORE      PIC 9(03) COMP-3.
               10  FILLER                          PIC X(134).